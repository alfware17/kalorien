Excel Tabelle zum Erfassen von Lebensmittel/Mahlzeiten
und Ausrechnen der kcal.

Ben�tigt Excel 2010 (die Excel 2003 Version ist ohne 
die Makros zum Ausw�hlen nicht voll funktionsf�hig)


(c) ALFWARE Bernd Schubert